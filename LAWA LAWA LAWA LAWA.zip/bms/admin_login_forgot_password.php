<?php
require_once 'db.php';  // Include database connection
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the email from the form
    $email = $_POST['email'];
    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        // Email found, redirect to reset-password.php
        header("Location: admin_login_reset_password.php?email=" . urlencode($email));
        exit();
    } else {
        echo "<p>Email address not found. Please try again.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-section">
        <div class="login-container">
            <h1>Reset Password</h1>
            <form action="admin_login_forgot_password.php" method="POST">
                <div class="input-group">
                    <label for="email">Enter your email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <button type="submit" class="submit-button">Reset Password</button>
            </form>
        </div>
    </div>
</body>
</html>