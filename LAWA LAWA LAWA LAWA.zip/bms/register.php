<?php
session_start(); // Start the session

include 'db.php'; // Include the database connection

// Initialize error variables
$username_error = $email_error = $password_error = $confirm_password_error = '';
$username = $email = $password = $confirm_password = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $_POST['username'];  // Get the username from form
    $email = $_POST['mail'];
    $password = $_POST['pass'];
    $confirm_password = $_POST['confirm_pass'];

    // Validate username
    if (empty($username)) {
        $username_error = 'Username is required';
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_error = 'Invalid email format';
    }

    // Validate password
    if (strlen($password) < 6) {
        $password_error = 'Password must be at least 6 characters';
    }

    // Validate confirm password
    if ($password !== $confirm_password) {
        $confirm_password_error = 'Passwords do not match';
    }

    // Check if username or email already exists in the database
    if (!$username_error && !$email_error && !$confirm_password_error) {
        // Check if email or username already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $username]);
        $user = $stmt->fetch();

        if ($user) {
            if ($user['email'] === $email) {
                $email_error = 'Email already exists';
            }
            if ($user['username'] === $username) {
                $username_error = 'Username already exists';
            }
        } else {
            // Hash the password before storing it
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user into database
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$username, $email, $hashed_password]);

            // Redirect to login page after successful registration
            header("Location: index.php");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Blotter System - Registration</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>

    <section class="login-section">
        <div class="login-container">
            <div class="form-inner">
                <h1>Create an Account</h1>
                <!-- Registration Form -->
                <form method="POST">
                    <!-- Username Field -->
                    <div class="input-group">
                        <label for="username">Username:</label>
                        <input type="text" 
                               id="username" 
                               name="username" 
                               class="input-field <?php echo ($username_error) ? 'error' : ''; ?>" 
                               placeholder="Enter your username" 
                               value="<?php echo htmlspecialchars($username); ?>" 
                               required>
                        <?php if ($username_error) echo "<span class='error-msg'>$username_error</span>"; ?>
                    </div>

                    <!-- Email Field -->
                    <div class="input-group">
                        <label for="email">Email:</label>
                        <input type="email" 
                               id="email" 
                               name="mail" 
                               class="input-field <?php echo ($email_error) ? 'error' : ''; ?>" 
                               placeholder="Enter your email"
                               value="<?php echo htmlspecialchars($email); ?>" 
                               required>
                        <?php if ($email_error) echo "<span class='error-msg'>$email_error</span>"; ?>
                    </div>

                    <!-- Password Field -->
                    <div class="input-group">
                        <label for="password">Password:</label>
                        <input type="password" 
                               id="password" 
                               name="pass" 
                               class="input-field <?php echo ($password_error) ? 'error' : ''; ?>" 
                               placeholder="Enter your password"
                               required>
                        <?php if ($password_error) echo "<span class='error-msg'>$password_error</span>"; ?>
                    </div>

                    <!-- Confirm Password Field -->
                    <div class="input-group">
                        <label for="confirm-password">Confirm Password:</label>
                        <input type="password" 
                               id="confirm-password" 
                               name="confirm_pass" 
                               class="input-field <?php echo ($confirm_password_error) ? 'error' : ''; ?>" 
                               placeholder="Confirm your password"
                               required>
                        <?php if ($confirm_password_error) echo "<span class='error-msg'>$confirm_password_error</span>"; ?>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="submit-button">Register</button>

                    <!-- Link to Login page -->
                    <p class="sign-up-prompt">Already have an account? <a href="index.php">Login</a></p>
                </form>
            </div>
        </div>
    </section>

</body>
</html>
