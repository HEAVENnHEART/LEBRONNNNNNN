<?php
require_once 'db.php';  // Include database connection

// Check if the email is passed in the URL
if (isset($_GET['email'])) {
    $email = $_GET['email'];

    // Handle form submission for resetting the password
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $new_password = $_POST['password'];

        // Validate and hash the new password
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

        // Update the password in the database
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashed_password, $email);
        $stmt->execute();

        // Redirect the user to index.php after password reset
        header("Location: index.php");
        exit();  // Make sure no further code is executed
    }
} else {
    echo "<p>No email provided. Please go back and try again.</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>
    <div class="login-section">
        <div class="login-container">
            <h1>Reset Password</h1>

            <form action="admin_login_reset_password.php?email=<?php echo urlencode($email); ?>" method="POST">
                <div class="input-group">
                    <label for="password">New Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="submit-button">Reset Password</button>
            </form>
        </div>
    </div>
</body>
</html>