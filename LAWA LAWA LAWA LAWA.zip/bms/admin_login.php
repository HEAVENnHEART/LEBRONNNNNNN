<?php
session_start(); // Start the session

include 'db.php'; // Include the database connection

// Initialize error variables
$email_error = $password_error = '';
$email = $password = '';

// Initialize failed login attempts
if (!isset($_SESSION['failed_attempts'])) {
    $_SESSION['failed_attempts'] = 0; // Initialize failed attempts counter
}
if (!isset($_SESSION['lockout_time'])) {
    $_SESSION['lockout_time'] = 0; // Initialize lockout time
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['mail'];
    $password = $_POST['pass'];

    // Check if the user is locked out
    if ($_SESSION['failed_attempts'] >= 5 && (time() - $_SESSION['lockout_time'] < 60)) {
        // Display lockout warning
        echo "<script>alert('Your account has been locked due to multiple failed login attempts. Please try again after 1 minutes.');</script>";
        exit();
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_error = 'Invalid email format';
    }

    // Check if email exists in the database
    if (!$email_error) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Successful login, reset failed attempts counter
            $_SESSION['failed_attempts'] = 0;

            // Store user information in session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];

            // Redirect to home page after successful login
            header("Location: dashboard.php");
            exit();
        } else {
            // Increment failed attempts counter
            $_SESSION['failed_attempts']++;

            // Lockout user if failed attempts exceed 5
            if ($_SESSION['failed_attempts'] >= 5) {
                $_SESSION['lockout_time'] = time(); // Record the lockout time
                $password_error = 'You have made 5 incorrect attempts. Your account is locked for 1 minutes.';
            } else {
                $password_error = 'Invalid email or password';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="CSS/style.css">
    
</head>
<body>
    <section class="login-section">
        <div class="login-container">
            <div class="form-inner">
                <h1>Lawa Management System</h1>
                <!-- Login Form -->
                <form method="POST">
                    <div class="input-group">
                        <label for="email">Email:</label>
                        <input type="email" 
                               id="email" 
                               name="mail" 
                               class="input-field <?php echo ($email_error) ? 'error' : ''; ?>" 
                               placeholder="Enter your email"
                               value="<?php echo htmlspecialchars($email); ?>" 
                               required>
                        <?php if ($email_error) echo "<span class='error-msg'>$email_error</span>"; ?>
                    </div>

                    <div class="input-group">
                        <label for="password">Password:</label>
                        <input type="password" 
                               id="password" 
                               name="pass" 
                               class="input-field <?php echo ($password_error) ? 'error' : ''; ?>" 
                               placeholder="Enter your password"
                               required>
                        <?php if ($password_error) echo "<span class='error-msg'>$password_error</span>"; ?>
                    </div>

                    <button type="submit" class="submit-button">Login</button>
                    <a href="admin_login_forgot_password.php">Forgot Password/ Reset Password</a>

                </form>
            </div>
        </div>
    </section>

</body>
</html>