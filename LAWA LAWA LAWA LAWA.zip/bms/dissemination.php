<?php
include 'db.php'; // Include the database connection

session_start(); // Start the session

// Check if the user is logged in (session variable exists)
if (!isset($_SESSION['user_id'])) {
    // If no session, redirect to login page
    header("Location: admin_login.php");
    exit(); // Stop further execution
}

// Fetch the user's information based on the user_id stored in the session
$user_id = $_SESSION['user_id']; // Get the user ID from the session
try {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC); // Get user info
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dissemination</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/dissemination.css">
    <link rel="stylesheet" href="CSS/sidebar.css">
    
    
</head>
<body>

<div class="wrapper">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <a href="dashboard.php">
                <img src="IMG/lawa-logo.jpg" alt="Logo" class="logo-image">
            </a>
        </div>

        <!-- Display the logged-in user's name in the sidebar -->
        <hr><br>
        <ul>
            <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
        </ul><br><hr><br>

        <ul>
    <li><a href="dashboard.php">Dashboard</a></li>
    <li class="has-submenu">
        <a href="#" class="blotter-menu">Blotter</a>
        <ul class="submenu">
            <li><a href="blotter_form.php">Forms</a></li>
            <li><a href="blotter_record.php">Record</a></li>
        </ul>
    </li>
    <li><a href="document_request.php">Request</a></li>
    <li><a href="dissemination.php">Dissemination</a></li>
    <li><a href="account.php">Account</a></li>
    <li><a href="admin_logout.php">Log Out</a></li>
</ul>

    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1>Dissemination</h1>
        </div>

        

        

        <div class="container">
    <div class="post-container">
        <h2>Create Facebook Post</h2>
        <form id="postForm" class="post-form">
            <div class="input-group">
                <label for="postContent">Post Content</label>
                <textarea id="postContent" name="content" placeholder="What's on your mind?" required></textarea>
            </div>

            <div class="input-group">
                <label for="mediaUpload">Add Media</label>
                <input type="file" id="mediaUpload" name="media" accept="image/*,video/*">
                <div id="mediaPreview" class="media-preview"></div>
            </div>

            <div class="input-group">
                <label>
                    <input type="checkbox" id="scheduleToggle"> Schedule Post
                </label>
                <div id="scheduleOptions" style="display: none;">
                    <input type="datetime-local" name="scheduleTime">
                </div>
            </div>

            <div class="post-actions">
                <button type="submit" class="post-button post-now">Post Now</button>
                <button type="button" class="post-button schedule-post">Schedule Post</button>
            </div>
        </form>
    </div>

    <div class="post-history">
        <h3>Recent Posts</h3>
        <div id="postsHistory"></div>
    </div>

    <div id="notification" style="display: none;"></div>
</div>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2025 Lawa Management System. All Rights Reserved.</p>
</div>


<script src="JS/dissemination.js"></script>

</body>
</html>