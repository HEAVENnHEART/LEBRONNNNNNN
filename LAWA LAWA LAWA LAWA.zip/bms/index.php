<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lawa Public Portal</title>
    <link rel="stylesheet" href="CSS/index.css">
    <link rel="stylesheet" href="CSS/style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/> <!--swiper/slide-->
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script> 
  <script src="JS/swiper.js"></script>

</head>
<body>
    <nav class="navbar">
        <div class="logo">Lawa Public Portal</div>
        <ul class="nav-links">
            <li><a href="#home">Home</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
            <?php if(isset($_SESSION['user'])): ?>
    <li class="user-menu">
        <a href="#" class="user-trigger">
            <img src="IMG/placeholderuser.png" alt="User" class="user-avatar">
            <?php echo htmlspecialchars($_SESSION['user']['username']); ?>
        </a>
        <ul class="index-dropdown-menu">
            <li><a href="profile.php">Profile</a></li>
            <li><a href="track-documents.php">Track Documents</a></li>
            <li><a href="public_logout.php">Logout</a></li>
        </ul>
    </li>
<?php else: ?>
    <li><a href="#" onclick="openLoginModal()">Login</a></li>
<?php endif; ?>
        </ul>
    </nav>
    

    <main>
        <section id="home" class="hero">
            <h1>Welcome to Barangay Lawa Online Portal</h1>
            <p>Serving the Community, Connecting Lives.</p>
            <button class="cta-button">Learn More</button>
        </section>

        <section id="services" class="services">
            <h2>Our Services</h2>
            <div class="cardBox">
                <div class="card">
                    <div>
                        <div class="cardName">Clearance</div>
                    </div>
                    <div class="iconBox"><ion-icon name="document-outline"></ion-icon></div>
                </div>

                <div class="card">
                    <div>
                        <div class="cardName">Indigency</div>
                    </div>
                    <div class="iconBox"><ion-icon name="document-outline"></ion-icon></div>
                </div>

                <div class="card">
                    <div>
                        <div class="cardName">Business Permit</div>
                    </div>
                    <div class="iconBox"><ion-icon name="document-outline"></ion-icon></div>
                </div>
            </div>

            <div class="cardBox">
                <div class="card">
                    <div>
                        <div class="cardName">Blotter</div>
                    </div>
                    <div class="iconBox"><ion-icon name="document-outline"></ion-icon></div>
                </div>

                <div class="card">
                    <div>
                        <div class="cardName">Registration</div>
                    </div>
                    <div class="iconBox"><ion-icon name="document-outline"></ion-icon></div>
                </div>

                <div class="card">
                    <div>
                        <div class="cardName">Announcements</div>
                    </div>
                    <div class="iconBox"><ion-icon name="document-outline"></ion-icon></div>
                </div>
            </div>
        </section>

        <section id="about" class="about">
            <h2>About Us</h2>
            <div class="container swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="IMG/p1.jpg" alt="Card Image" class="card-image"> 
                        <p class="badge">Barangay Captain</p>
                        <h2 class="card-title">Emmanuel "PACO" Nido</h2>
                    </div>

                    <div class="swiper-slide">
                        <img src="IMG/p1.jpg" alt="Card Image" class="card-image"> 
                        <p class="badge">Barangay Captain</p>
                        <h2 class="card-title">Emmanuel "PACO" Nido</h2>
                    </div>

                    <div class="swiper-slide">
                        <img src="IMG/p1.jpg" alt="Card Image" class="card-image"> 
                        <p class="badge">Barangay Captain</p>
                        <h2 class="card-title">Emmanuel "PACO" Nido</h2>
                    </div>

                    <div class="swiper-slide">
                        <img src="IMG/p1.jpg" alt="Card Image" class="card-image"> 
                        <p class="badge">Barangay Captain</p>
                        <h2 class="card-title">Emmanuel "PACO" Nido</h2>
                    </div>

                    <div class="swiper-slide">
                        <img src="IMG/p1.jpg" alt="Card Image" class="card-image"> 
                        <p class="badge">Barangay Captain</p>
                        <h2 class="card-title">Emmanuel "PACO" Nido</h2>
                    </div>
                </div>

                <!-- Add Pagination -->
                <div class="swiper-pagination"></div>

                <!-- Add Navigation Buttons -->
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
        </section>
    
    </main>

    <footer class="footer">
    <div class="footer-container">
        <h2> Contact Us </h2>
                <div class="footer-row"> 
                    <div class="footer-col"> 
                        <h4>Hotlines</h4>
                        <ul> 
                            <li><a href="#">Police: 123-456-7890</a></li>
                            <li><a href="#">Fire Department: 098-765-4321</a></li>
                            <li><a href="#">Medical Emergency: 112</a></li>
                        </ul>
 
                        <h4>Get Help</h4>
                        <ul> 
                            <li><a href="#">FAQ</a></li>
                            <li><a href="#">Support</a></li>
                        </ul>

                        <h4>Follow Us</h4>
                        <div class="social-links"> 
                            <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
                            <a href="#"><ion-icon name="mail-outline"></ion-icon></a>
                        </div>
                    </div>
                </div>
            </div>
        <p>&copy; 2025 Lawa Management System. All rights reserved.</p>
    </footer>


    <!--login Modal-->
    <div id="loginModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <div class="login-container">
            <h2>Login</h2>
            <form action="public_login.php" method="POST">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit">Login</button>
                <p>Don't have an account? <a href="#" onclick="openSignupModal()">Sign up</a></p>
            </form>
        </div>
    </div>
</div>

<div id="signupModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <div class="signup-container">
            <h2>Sign Up</h2>
            <form action="public_register.php" method="POST">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" name="confirm_password" required>
                </div>
                <button type="submit">Sign Up</button>
            </form>
        </div>
    </div>
</div>
<script src="JS/modal.js"></script>
</body>
</html>
