<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id']) || empty($_POST['id']) || empty($_POST['status'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$request_id = $_POST['id'];
$status = $_POST['status'];

try {
    $stmt = $pdo->prepare("UPDATE document_requests SET status = ? WHERE id = ?");
    $stmt->execute([$status, $request_id]);
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>