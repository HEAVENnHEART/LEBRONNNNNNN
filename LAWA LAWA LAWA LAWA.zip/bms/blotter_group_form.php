<?php
include 'db.php';
session_start();
$successMessage = '';  // Variable to store success message
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
$groupName = $_POST['group_name'];
$name = $_POST['name'];
$address = $_POST['address'];
$case = $_POST['case'];
$contact = $_POST['contact'];
$time = $_POST['time'];
// Concatenate the date fields into a valid format (YYYY-MM-DD)
$month = $_POST['month'];
$day = $_POST['day'];
$year = $_POST['year'];
$date = $year . '-' . $month . '-' . $day;  // This will result in "YYYY-MM-DD" format
$description = $_POST['description'];
$suspectName = $_POST['suspect_name'];
$position = $_POST['position'];  // Collect position field

// Insert record into `grecords` table
try {
    $stmt = $pdo->prepare("INSERT INTO grecords (group_name, name, address, case_type, contact, time, month, day, year, description, suspect_name, position) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$groupName, $name, $address, $case, $contact, $time, $month, $day, $year, $description, $suspectName, $position]);  // Use $position

    // Set success message
    $successMessage = 'Blotter is added successfully';
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
}
// Check if user session is set
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $sql_users = "SELECT * FROM users WHERE id = :user_id";  // Use parameterized query to prevent SQL injection
    $stmt_users = $pdo->prepare($sql_users);
    $stmt_users->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_users->execute();

    if ($stmt_users->rowCount() > 0) {
        $user = $stmt_users->fetch(PDO::FETCH_ASSOC); // Fetch the user as an associative array
    } else {
        echo "User not found.";
        exit(); // Stop execution if user is not found
    }
} else {
    echo "Session not started. Please log in.";
    exit(); // Stop execution if session is not found
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blotter</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/blotter_group_form.css">
    <link rel="stylesheet" href="CSS/sidebar.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-section">
                <a href="dashboard.php">
                    <img src="IMG/lawa-logo.jpg" alt="Logo" class="logo-image">
                </a>
            </div>
            <hr><br>
            <ul>
                <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
            </ul><br><hr><br>
            <ul>
    <li><a href="dashboard.php">Dashboard</a></li>
    <li class="has-submenu">
        <a href="#" class="blotter-menu">Blotter</a>
        <ul class="submenu">
            <li><a href="blotter_form.php">Forms</a></li>
            <li><a href="blotter_record.php">Record</a></li>
        </ul>
    </li>
    <li><a href="document_request.php">Request</a></li>
    <li><a href="dissemination.php">Dissemination</a></li>
    <li><a href="account.php">Account</a></li>
    <li><a href="admin_logout.php">Log Out</a></li>
</ul>
        </div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Group Form</h1>
            </div>
            <div class="container">
                <!-- Success Notification -->
                <?php if ($successMessage): ?>
                    <div class="notification" id="notification"><?= htmlspecialchars($successMessage) ?></div>
                <?php endif; ?>
                <form method="POST" action="">
    <label for="group_name">Group Name:</label>
    <input type="text" id="group_name" name="group_name" placeholder="Group Name" required>
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" placeholder="Name" pattern="[A-Za-z\s]+" title="Name must only contain letters and spaces" required>
    <label for="contact">Contact Number:</label>
    <input type="text" id="contact" name="contact" placeholder="Contact Number" pattern="\d+" title="Contact number must only contain numbers" required>
    <label for="address">Address:</label>
    <input type="text" id="address" name="address" placeholder="Address" required>
    <div class="form-group">
        <div class="time-group">
            <label for="time">Time:</label>
            <input type="time" id="time" name="time" required>
        </div>
        <div class="month-group">
            <label for="month">Month:</label>
            <select id="month" name="month" required>
                <option value="">Select Month</option>
                <option value="January">January</option>
                <option value="February">February</option>
                <option value="March">March</option>
                <option value="April">April</option>
                <option value="May">May</option>
                <option value="June">June</option>
                <option value="July">July</option>
                <option value="August">August</option>
                <option value="September">September</option>
                <option value="October">October</option>
                <option value="November">November</option>
                <option value="December">December</option>
            </select>
        </div>
        <div class="day-group">
            <label for="day">Day:</label>
            <input type="text" id="day" name="day" placeholder="Day" pattern="\d+" title="Day must only contain numbers" required>
        </div>
        <div class="year-group">
            <label for="year">Year:</label>
            <input type="text" id="year" name="year" placeholder="Year" pattern="\d+" title="Year must only contain numbers" required>
        </div>
    </div>
    <label for="case">Case:</label>
    <input type="text" id="case" name="case" placeholder="Case" pattern="[A-Za-z\s]+" title="Name must only contain letters and spaces" required>
    <label for="description">Description:</label>
    <textarea id="description" name="description" placeholder="Description" required></textarea>
    <label for="suspect_name">Respondent Name:</label>
    <input type="text" id="suspect_name" name="suspect_name" placeholder="Respondent Name" pattern="[A-Za-z\s]+" title="Name must only contain letters and spaces" required>
    <label for="position">Official:</label>
    <input type="text" id="position" name="position" placeholder="Official's Position" pattern="[A-Za-z\s]+" title="Position must only contain letters and spaces" required>
    <div class="button-container">
        <button type="submit">Submit Record</button>
    </div>
</form>
            </div>
        </div>
        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2025 Lawa Management System. All rights reserved.</p>
        </div>
    </div>
    <script src="JS/blotter_group_form.js"></script>
</body>
</html>