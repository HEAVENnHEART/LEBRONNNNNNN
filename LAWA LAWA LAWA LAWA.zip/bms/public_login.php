<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email']
        ];
        
        // Check user role and redirect accordingly
        if ($user['role'] === 'admin') {
            header("Location: dashboard.php");
        }  else if ($user['role'] === 'sub_admin') {
            header("Location: dashboard.php");
        }  else {
           header("Location: index.php");
        }

        exit();
    }
}

header("Location: index.php?error=invalid_credentials");
exit();

