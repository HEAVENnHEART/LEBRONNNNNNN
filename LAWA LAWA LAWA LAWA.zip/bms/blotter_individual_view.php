<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM records WHERE id = ?");
    $stmt->execute([$id]);
    $record = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Fetch involved parties
    $partyStmt = $pdo->prepare("SELECT * FROM involved_parties WHERE record_id = ?");
    $partyStmt->execute([$id]);
    $involvedParties = $partyStmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    header("Location: blotter_individual_record.php");
    exit();
}

// Start the session and check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    // If no session, redirect to login page
    header("Location: index.php");
    exit(); // Stop further execution
}

// Fetch the user's information based on the user_id stored in the session
$user_id = $_SESSION['user_id']; // Get the user ID from the session
try {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC); // Get user info
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blotter</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/blotter_individual_view.css">

    
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <div class="logo-section">
                <a href="dashboard.php">
                    <img src="IMG/lawa-logo.jpg" alt="Logo" class="logo-image">
                </a>
            </div>
            <!-- Display the logged-in user's name in the sidebar -->
            <hr><br>
            <ul>
                <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
            </ul><br><hr><br>
            <ul>
                <li><a href="blotter_individual_record.php">Back</a></li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="header">
                <h1>View Record</h1>
            </div>
            <div class="container">
                <h3>Complainant</h3>
                <br>
                <p><strong>Name:</strong> <?= htmlspecialchars($record['name']) ?></p><br>
                <p><strong>Age:</strong> <?= htmlspecialchars($record['age']) ?></p><br>
                <p><strong>Gender:</strong> <?= htmlspecialchars($record['gender']) ?></p><br>
                <p><strong>Relationship:</strong> <?= htmlspecialchars($record['relationship']) ?></p><br>
                <p><strong>Contact Number:</strong> <?= htmlspecialchars($record['contact']) ?></p><br>
                <p><strong>Address:</strong> <?= htmlspecialchars($record['address']) ?></p><br><hr><br>
                <h3>Respondent</h3><br>
                <?php foreach ($involvedParties as $party): ?>
                    <p><strong>Name:</strong> <?= htmlspecialchars($party['name']) ?></p><br>
                    <p><strong>Age:</strong> <?= htmlspecialchars($party['age']) ?></p><br>
                    <p><strong>Gender:</strong> <?= htmlspecialchars($party['gender']) ?></p><br>
                    <p><strong>Address:</strong> <?= htmlspecialchars($party['address']) ?></p>
                <?php endforeach; ?><br><hr><br>
                <h3>Official</h3><br>
                <p><strong>Position:</strong> <?= htmlspecialchars($record['position']) ?></p><br><hr><br>
                <h3>Case Details</h3><br>
                <p><strong>Date:</strong> <?= htmlspecialchars ($record['month']) ?> <?= htmlspecialchars ($record['day']) ?> <?= htmlspecialchars ($record['year']) ?></p><br>
                <p><strong>Time:</strong> <?= htmlspecialchars($record['time']) ?></p><br>
                <p><strong>Case:</strong> <?= htmlspecialchars($record['case_type']) ?></p><br>
                <p><strong>Description:</strong> <?= htmlspecialchars($record['description']) ?></p><br>
            </div>
        </div>
        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2025 Lawa Mangement System. All rights reserved.</p>
        </div>
    </div>
</body>
</html>