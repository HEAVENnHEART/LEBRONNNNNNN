<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $document_type = $_POST['document_type'];
    $purpose = $_POST['purpose'];

    $stmt = $pdo->prepare("INSERT INTO document_requests (fullname, email, phone, document_type, purpose) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$fullname, $email, $phone, $document_type, $purpose]);

    header("Location: index.php#request");
    exit();
}
?>
