<?php
include 'db.php';
session_start();
$successMessage = '';  // Variable to store success message
// Check if user session is set
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $sql_users = "SELECT * FROM users WHERE id = :user_id";  // Use parameterized query to prevent SQL injection
    $stmt_users = $pdo->prepare($sql_users);
    $stmt_users->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_users->execute();

    if ($stmt_users->rowCount() > 0) {
        $user = $stmt_users->fetch(PDO::FETCH_ASSOC); // Fetch the user as an associative array
    } else {
        echo "User not found.";
        exit(); // Stop execution if user is not found
    }
} else {
    echo "Session not started. Please log in.";
    exit(); // Stop execution if session is not found
}
// Check if the 'id' parameter is passed in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    // Fetch the existing record from the database
    $sql = "SELECT * FROM grecords WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    // Check if the record exists
    if ($stmt->rowCount() > 0) {
        $record = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "Record not found.";
        exit();
    }
} else {
    echo "No record ID provided.";
    exit();
}
// Handle the form submission for updating the record
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $groupName = $_POST['group_name'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $case = $_POST['case'];
    $time = $_POST['time'];
    // Concatenate the date fields into a valid format (YYYY-MM-DD)
    $month = $_POST['month'];
    $day = $_POST['day'];
    $year = $_POST['year'];
    $date = $year . '-' . $month . '-' . $day;  // This will result in "YYYY-MM-DD" format
    $description = $_POST['description'];
    $suspectName = $_POST['suspect_name'];
    $position = $_POST['position'];
    // Update record in `grecords` table
    try {
        $stmt = $pdo->prepare("UPDATE grecords SET group_name = ?, name = ?, address = ?, case_type = ?, contact = ?, time = ?, month = ?, day = ?, year = ?, description = ?, suspect_name = ?, position = ? WHERE id = ?");
        $stmt->execute([$groupName, $name, $address, $case, $contact, $time, $month, $day, $year, $description, $suspectName, $position, $id]);

        // Set success message
        $successMessage = 'Record has been updated successfully.';

        // Redirect to group-record.php after successful update
        header('Location: blotter_group_record.php'); 
        exit(); // Stop further script execution after redirect
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blotter</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/blotter_group_edit.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-section">
                <a href="dashboard.php">
                    <img src="IMG/lawa-logo.jpg" alt="Logo" class="logo-image">
                </a>
            </div>
            <!-- Display the logged-in user's name in the sidebar -->
            <hr><br>
            <ul>
                <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
            </ul><br><hr><br>
            <ul>
                <li><a href="blotter_group_record.php">Back</a></li>
            </ul>
        </div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Edit Group Record</h1>
            </div>
            <div class="container">
                <!-- Success Notification -->
                <?php if ($successMessage): ?>
                    <div class="notification" id="notification"><?= htmlspecialchars($successMessage) ?></div>
                <?php endif; ?>
                <!-- Edit Form -->
                <form method="POST" action="">
                    <label for="group_name">Group Name:</label>
                    <input type="text" id="group_name" name="group_name" value="<?= htmlspecialchars($record['group_name']) ?>" required>
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($record['name']) ?>" required>
                    <label for="contact">Contact Number:</label>
                    <input type="text" id="contact" name="contact" value="<?= htmlspecialchars($record['contact']) ?>" required>
                    <label for="address">Address:</label>
                    <input type="text" id="address" name="address" value="<?= htmlspecialchars($record['address']) ?>" required>
                    <div class="form-group">
                        <div class="time-group">
                            <label for="time">Time:</label>
                            <input type="time" id="time" name="time" value="<?= htmlspecialchars($record['time']) ?>" required>
                        </div>
                        <div class="month-group">
                            <label for="month">Month:</label>
                            <select id="month" name="month" required>
                                <option value="<?= htmlspecialchars($record['month']) ?>"><?= htmlspecialchars($record['month']) ?></option>
                                <!-- List of months, you can add all the months here -->
                                <option value="January">January</option>
                                <option value="February">February</option>
                                <option value="March">March</option>
                                <option value="April">April</option>
                                <option value="May">May</option>
                                <option value="June">June</option>
                                <option value="July">July</option>
                                <option value="August">August</option>
                                <option value="September">September</option>
                                <option value="October">October</option>
                                <option value="November">November</option>
                                <option value="December">December</option>
                            </select>
                        </div>
                        <div class="day-group">
                            <label for="day">Day:</label>
                            <input type="text" id="day" name="day" value="<?= htmlspecialchars($record['day']) ?>" required>
                        </div>
                        <div class="year-group">
                            <label for="year">Year:</label>
                            <input type="text" id="year" name="year" value="<?= htmlspecialchars($record['year']) ?>" required>
                        </div>
                    </div>
                    <label for="case">Case:</label>
                    <input type="text" id="case" name="case" value="<?= htmlspecialchars($record['case_type']) ?>" required>
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" required><?= htmlspecialchars($record['description']) ?></textarea>
                    <label for="suspect_name">Respondent Name:</label>
                    <input type="text" id="suspect_name" name="suspect_name" value="<?= htmlspecialchars($record['suspect_name']) ?>" required>
                    <label for="position">Official:</label>
                    <input type="text" id="position" name="position" value="<?= htmlspecialchars($record['position']) ?>" required>
                    <div class="button-container">
                        <button type="submit">Update Record</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2025 Lawa Mangement System. All rights reserved.</p>
        </div>
    </div>
</body>
</html>