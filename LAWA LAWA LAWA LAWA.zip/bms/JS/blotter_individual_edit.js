document.getElementById("addParty").addEventListener("click", function() {
    const partyDiv = document.createElement("div");
    partyDiv.classList.add("party");
    partyDiv.innerHTML = '<input type="text" name="party_name[]" placeholder="Involved Party Name" required>' +
                        '<input type="text" name="party_age[]" placeholder="Age" required>' +
                        '<input type="text" name="party_gender[]" placeholder="Gender" required>' +
                        '<input type="text" name="party_address[]" placeholder="Address" required>';
    document.getElementById("involvedParties").appendChild(partyDiv);
});