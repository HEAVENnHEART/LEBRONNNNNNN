function updateStatus(requestId, status) {
    if (confirm('Are you sure you want to ' + status + ' this request?')) {
        fetch('update_request_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + requestId + '&status=' + status
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error updating status: ' + data.message);
            }
        });
    }
}

function printRequest(id) {
    fetch(`document_request.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            const printContent = `
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Barangay Document Request #${id}</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        #content { width: 80%; margin: 0 auto; padding: 20px; }
                        h1 { text-align: center; margin-bottom: 20px; }
                        .section { margin-bottom: 20px; }
                        .section h3 { margin-bottom: 10px; font-size: 18px; text-decoration: underline; }
                        .section p { margin: 5px 0; }
                        .signature-section { 
                            margin-top: 100px;
                            display: flex;
                            justify-content: space-between;
                        }
                        .signature-box {
                            text-align: center;
                            width: 200px;
                        }
                        .signature-line {
                            border-top: 1px solid black;
                            margin-top: 50px;
                        }
                        @media print { @page { margin: 2cm; } }
                    </style>
                </head>
                <body>
                    <div id="content">
                        <h1>Barangay Document Request</h1>
                        <p>Date: ${new Date().toLocaleDateString()}</p>
                        <p>To Whom It May Concern,</p>
                        <p>This is to certify that the following document request has been made:</p>
                        <div class="section">
                            <h3>Request Details</h3>
                            <p><strong>Document Type:</strong> ${data.document_type}</p>
                            <p><strong>Purpose:</strong> ${data.purpose}</p>
                            <p><strong>Status:</strong> ${data.status}</p>
                            <p><strong>Date Requested:</strong> ${data.created_at}</p>
                        </div>
                        <p>Thank you for your attention to this matter.</p>
                        <div class="signature-section">
                            <div class="signature-box">
                                <div class="signature-line"></div>
                                <p>Barangay Captain's Signature</p>
                            </div>
                        </div>
                    </div>
                    <script>
                        window.onload = function() { window.print(); }
                    </script>
                </body>
                </html>
            `;

            // Store original content
            const originalContent = document.body.innerHTML;
            
            // Set print content
            document.body.innerHTML = printContent;
            
            // Print and restore
            window.onafterprint = function() {
                document.body.innerHTML = originalContent;
                location.reload();
            };
            
            window.print();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error loading request data');
        });
}

function viewRequest(id) {
    fetch(`document_request.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('modalName').textContent = data.fullname;
            document.getElementById('modalEmail').textContent = data.email;
            document.getElementById('modalPhone').textContent = data.phone;
            document.getElementById('modalDocumentType').textContent = data.document_type;
            document.getElementById('modalPurpose').textContent = data.purpose;
            document.getElementById('modalStatus').textContent = data.status;
            document.getElementById('modalDateRequested').textContent = data.created_at;
            document.getElementById('viewModal').style.display = 'block';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error loading request data');
        });
}

function closeModal() {
    document.getElementById('viewModal').style.display = 'none';
}