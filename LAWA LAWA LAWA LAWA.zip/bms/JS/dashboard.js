const ctx1 = document.getElementById('caseChart').getContext('2d');
const caseChart = new Chart(ctx1, {
    type: 'pie',
    data: {
        labels: chartLabels,
        datasets: [{
            label: 'Number of Cases by Type',
            data: chartData,
            backgroundColor: [
                'rgba(255, 99, 132, 0.6)',
                'rgba(54, 162, 235, 0.6)',
                'rgba(75, 192, 192, 0.6)',
                'rgba(153, 102, 255, 0.6)',
                'rgba(255, 159, 64, 0.6)',
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' },
            title: { display: true, text: 'Case Type Distribution' }
        }
    }
});

document.addEventListener('DOMContentLoaded', function () {
    // Case Types Chart
    const ctx = document.getElementById('caseChart').getContext('2d');
    const caseChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: chartLabels,
            datasets: [{
                label: 'Case Types',
                data: chartData,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Case Types Distribution'
                }
            }
        }
    });

    // Monthly Cases Chart
    const monthCtx = document.getElementById('monthChart').getContext('2d');
    const monthChart = new Chart(monthCtx, {
        type: 'bar',
        data: {
            labels: monthLabels,
            datasets: [{
                label: 'Monthly Cases',
                data: monthCounts,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Monthly Case Report'
                }
            }
        }
    });

    // Gender Distribution Chart
    const genderCtx = document.getElementById('genderChart').getContext('2d');
    const genderChart = new Chart(genderCtx, {
        type: 'doughnut',
        data: {
            labels: genderLabels,
            datasets: [{
                label: 'Gender Distribution',
                data: genderCounts,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Gender Distribution'
                }
            }
        }
    });

    // Real-time updates (example: update every 60 seconds)
    setInterval(() => {
        fetch('dashboard_data.php?year=' + selectedYear)
            .then(response => response.json())
            .then(data => {
                // Update charts with new data
                caseChart.data.labels = data.caseLabels;
                caseChart.data.datasets[0].data = data.caseData;
                caseChart.update();

                monthChart.data.labels = data.monthLabels;
                monthChart.data.datasets[0].data = data.monthCounts;
                monthChart.update();

                genderChart.data.labels = data.genderLabels;
                genderChart.data.datasets[0].data = data.genderCounts;
                genderChart.update();

                // Update summary cards
                document.querySelector('.card.total-cases p').textContent = data.totalCases;
                document.querySelector('.card.open-cases p').textContent = data.openCases;
                document.querySelector('.card.closed-cases p').textContent = data.closedCases;
            });
    }, 60000); // Update every 60 seconds
});
