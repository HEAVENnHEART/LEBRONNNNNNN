// Show the notification if there is a success message
 if ($successMessage)
document.addEventListener('DOMContentLoaded', function() {
    const notification = document.getElementById("notification");
    notification.style.display = "block"; // Display the notification
    // Hide the notification after 3 seconds
    setTimeout(function() {
        notification.style.display = "none"; // Hide notification after 3 seconds
    }, 3000);
});
// Restrict input for name, position, and suspect name to alphabetic characters and spaces
document.getElementById('name').addEventListener('input', function(e) {
e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, '');  // Only allow alphabetic and space characters
});
document.getElementById('suspect_name').addEventListener('input', function(e) {
e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, '');  // Only allow alphabetic and space characters
});
document.getElementById('position').addEventListener('input', function(e) {
e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, '');  // Only allow alphabetic and space characters
});
// Restrict input for contact, day, and year to numbers
document.getElementById('contact').addEventListener('input', function(e) {
e.target.value = e.target.value.replace(/[^0-9]/g, '');  // Only allow numbers
});
document.getElementById('day').addEventListener('input', function(e) {
e.target.value = e.target.value.replace(/[^0-9]/g, '');  // Only allow numbers
});
document.getElementById('year').addEventListener('input', function(e) {
e.target.value = e.target.value.replace(/[^0-9]/g, '');  // Only allow numbers
});