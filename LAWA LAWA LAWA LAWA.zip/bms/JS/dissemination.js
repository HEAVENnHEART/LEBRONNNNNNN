
// Initialize Facebook SDK
window.fbAsyncInit = function() {
    FB.init({
        appId: 'YOUR_APP_ID',
        autoLogAppEvents: true,
        xfbml: true,
        version: 'v18.0'
    });
};

// Load Facebook SDK
(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s);
    js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

class DisseminationManager {
    constructor() {
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        document.getElementById('postForm').addEventListener('submit', this.handlePostSubmission.bind(this));
        document.getElementById('mediaUpload').addEventListener('change', this.handleMediaPreview.bind(this));
        document.getElementById('scheduleToggle').addEventListener('change', this.toggleScheduleOptions.bind(this));
    }

    async handlePostSubmission(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        
        try {
            const response = await fetch('/api/facebook/post', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            this.showNotification(result.message, result.success ? 'success' : 'error');
            
            if(result.success) {
                this.updatePostHistory();
            }
        } catch (error) {
            console.error('Post submission error:', error);
            this.showNotification('Failed to create post', 'error');
        }
    }

    handleMediaPreview(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                document.getElementById('mediaPreview').innerHTML = `
                    <img src="${e.target.result}" alt="Preview" style="max-width: 200px;">
                `;
            };
            reader.readAsDataURL(file);
        }
    }

    toggleScheduleOptions(event) {
        const scheduleOptions = document.getElementById('scheduleOptions');
        scheduleOptions.style.display = event.target.checked ? 'block' : 'none';
    }

    async updatePostHistory() {
        try {
            const response = await fetch('/api/facebook/posts/history');
            const history = await response.json();
            this.renderPostHistory(history);
        } catch (error) {
            console.error('Error fetching post history:', error);
        }
    }

    showNotification(message, type) {
        const notification = document.getElementById('notification');
        notification.textContent = message;
        notification.className = `notification ${type}`;
        notification.style.display = 'block';
        setTimeout(() => notification.style.display = 'none', 3000);
    }
}

// Initialize the manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new DisseminationManager();
});
