document.addEventListener("DOMContentLoaded", function () {
    var swiper = new Swiper('.swiper', {
        loop: true, // Enables infinite looping
        slidesPerView: 1,
        spaceBetween: 10,
        autoplay: {
            delay: 3000, // Adjust time between slides (in milliseconds)
            disableOnInteraction: false, // Keeps autoplay running even after user interaction
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
    });
});