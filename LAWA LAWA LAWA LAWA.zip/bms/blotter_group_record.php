<?php
include 'db.php';  // Include database connection
session_start();
$successMessage = '';  // Variable to store success message

// Check if user session is set
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $sql_users = "SELECT * FROM users WHERE id = :user_id";  // Use parameterized query to prevent SQL injection
    $stmt_users = $pdo->prepare($sql_users);
    $stmt_users->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_users->execute();
    if ($stmt_users->rowCount() > 0) {
        $user = $stmt_users->fetch(PDO::FETCH_ASSOC); // Fetch the user as an associative array
    } else {
        echo "User not found.";
        exit(); // Stop execution if user is not found
    }
} else {
    echo "Session not started. Please log in.";
    exit(); // Stop execution if session is not found
}

// Pagination Variables
$recordsPerPage = 7;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page, default is 1
$offset = ($page - 1) * $recordsPerPage; // Offset for SQL query

// Handle search and filter
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Prepare the base SQL query
try {
    $sql = "SELECT * FROM grecords WHERE ";
    if ($filter == 'all') {
        $sql .= "(group_name LIKE :searchTerm 
                OR name LIKE :searchTerm 
                OR time LIKE :searchTerm 
                OR description LIKE :searchTerm 
                OR suspect_name LIKE :searchTerm 
                OR position LIKE :searchTerm
                OR contact LIKE :searchTerm
                OR address LIKE :searchTerm
                OR case_type LIKE :searchTerm)";
    } else {
        $sql .= "$filter LIKE :searchTerm";  // Filter based on the selected field
    }
    $sql .= " ORDER BY id DESC LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':searchTerm', "%$searchTerm%");  // Bind search term
    $stmt->bindValue(':limit', $recordsPerPage, PDO::PARAM_INT);  // Limit for pagination
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);  // Offset for pagination
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Pagination - total records query
$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM grecords WHERE group_name LIKE :searchTerm 
                            OR name LIKE :searchTerm 
                            OR time LIKE :searchTerm 
                            OR description LIKE :searchTerm 
                            OR suspect_name LIKE :searchTerm 
                            OR position LIKE :searchTerm");
$totalStmt->bindValue(':searchTerm', "%$searchTerm%");
$totalStmt->execute();
$totalRecords = $totalStmt->fetchColumn();

// Calculate total pages
$totalPages = ceil($totalRecords / $recordsPerPage);

// Get counts of open and closed cases
$openCasesStmt = $pdo->prepare("SELECT COUNT(*) FROM grecords WHERE is_closed = 0");
$openCasesStmt->execute();
$openCasesCount = $openCasesStmt->fetchColumn();

$closedCasesStmt = $pdo->prepare("SELECT COUNT(*) FROM grecords WHERE is_closed = 1");
$closedCasesStmt->execute();
$closedCasesCount = $closedCasesStmt->fetchColumn();

// Get counts of cases by type
$caseTypesStmt = $pdo->prepare("SELECT case_type, COUNT(*) as count FROM grecords GROUP BY case_type");
$caseTypesStmt->execute();
$caseTypesCounts = $caseTypesStmt->fetchAll(PDO::FETCH_ASSOC);

// Handle delete action
if (isset($_GET['delete'])) {
    $deleteId = $_GET['delete'];
    try {
        $deleteStmt = $pdo->prepare("DELETE FROM grecords WHERE id = :id");
        $deleteStmt->execute(['id' => $deleteId]);
        header("Location: blotter_group_record.php?page=$page&search=" . urlencode($searchTerm) . "&filter=$filter"); // Refresh the page after deletion
        exit();
    } catch (PDOException $e) {
        echo "Error deleting record: " . $e->getMessage();
    }
}

// Handle status toggle action
if (isset($_GET['toggle_status'])) {
    $toggleId = $_GET['toggle_status'];
    try {
        // Fetch the current status to toggle it
        $statusStmt = $pdo->prepare("SELECT is_closed FROM grecords WHERE id = :id");
        $statusStmt->execute(['id' => $toggleId]);
        $currentStatus = $statusStmt->fetchColumn();
        
        // Toggle the status
        $newStatus = $currentStatus == 1 ? 0 : 1;
        
        $updateStmt = $pdo->prepare("UPDATE grecords SET is_closed = :status WHERE id = :id");
        $updateStmt->execute(['status' => $newStatus, 'id' => $toggleId]);
        header("Location: blotter_group_record.php?page=$page&search=" . urlencode($searchTerm) . "&filter=$filter"); // Refresh the page after status toggle
        exit();
    } catch (PDOException $e) {
        echo "Error updating status: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blotter</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/blotter_group_record.css">
    <link rel="stylesheet" href="CSS/sidebar.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-section">
                <a href="dashboard.php">
                    <img src="IMG/lawa-logo.jpg" alt="Logo" class="logo-image">
                </a>
            </div>
            <hr><br>
            <ul>
                <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
            </ul><br><hr><br>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li class="has-submenu">
                    <a href="#" class="blotter-menu">Blotter</a>
                    <ul class="submenu">
                        <li><a href="blotter_form.php">Forms</a></li>
                        <li><a href="blotter_record.php">Record</a></li>
                    </ul>
                </li>
                <li><a href="document_request.php">Request</a></li>
                <li><a href="dissemination.php">Dissemination</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="admin_logout.php">Log Out</a></li>
            </ul>
        </div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Group Records</h1>
            </div>
            <!-- Data Analytics Section -->
            <div class="analytics-container">
                <div class="analytics-box">
                    <div class="analytics">
                        <h2>Number of Cases</h2>
                        <p>Total Open Cases: <?= $openCasesCount ?></p>
                        <p>Total Closed Cases: <?= $closedCasesCount ?></p>
                    </div>
                </div>
                <div class="analytics-box">
                    <div class="analytics">
                        <h2>Type of Cases</h2>
                        <ul>
                            <?php foreach ($caseTypesCounts as $caseType): ?>
                                <li><?= htmlspecialchars($caseType['case_type']) ?>: <?= $caseType['count'] ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="container">
                <form method="GET" action="blotter_group_record.php">
                    <div class="search-container">
                        <input type="text" name="search" value="<?= htmlspecialchars($searchTerm) ?>" placeholder="Search records..." class="search-bar">
                        <select name="filter" class="filter-dropdown">
                            <option value="all" <?= $filter == 'all' ? 'selected' : '' ?>>All</option>
                            <option value="group_name" <?= $filter == 'group_name' ? 'selected' : '' ?>>Group Name</option>
                            <option value="name" <?= $filter == 'name' ? 'selected' : '' ?>>Name</option>
                            <option value="suspect_name" <?= $filter == 'suspect_name' ? 'selected' : '' ?>>Respondent</option>
                            <option value="position" <?= $filter == 'position' ? 'selected' : '' ?>>Official</option>
                            <option value="contact" <?= $filter == 'contact' ? 'selected' : '' ?>>Contact</option>
                            <option value="address" <?= $filter == 'address' ? 'selected' : '' ?>>Address</option>
                            <option value="case_type" <?= $filter == 'case_type' ? 'selected' : '' ?>>Case</option>
                        </select>
                        <button type="submit" class="search-button">Search</button>
                    </div>
                </form>
                <!-- Check if there are any records -->
                <?php if (is_array($records) && count($records) > 0): ?>
                    <div class="table-wrapper">
                    <table class="record-table">
                        <thead>
                            <tr>
                                <th>Group Name</th>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Address</th>
                                <th>Time</th>
                                <th>Date</th>
                                <th>Case</th>
                                <th>Respondent Name</th>
                                <th>Official</th>
                                <th>Action</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($records as $record): ?>
                                <tr>
                                    <td><?= htmlspecialchars($record['group_name']) ?></td>
                                    <td><?= htmlspecialchars($record['name']) ?></td>
                                    <td><?= htmlspecialchars($record['contact']) ?></td>
                                    <td><?= htmlspecialchars($record['address']) ?></td>
                                    <td><?= htmlspecialchars($record['time']) ?></td>
                                    <td>
                                        <?= htmlspecialchars($record['month']) ?>
                                        <?= htmlspecialchars($record['day']) ?>
                                        <?= htmlspecialchars($record['year']) ?>
                                    </td>
                                    <td><?= htmlspecialchars($record['case_type']) ?></td>
                                    <td><?= htmlspecialchars($record['suspect_name']) ?></td>
                                    <td style="font-style: italic;">
                                        <?= htmlspecialchars($record['position']) ?>
                                    </td>
                                    <td>
                                        <a href="blotter_group_view.php?id=<?= $record['id'] ?>&page=<?= $page ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>" class="view-button">View</a>
                                        <a href="blotter_group_edit.php?id=<?= $record['id'] ?>&page=<?= $page ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>" class="edit-button">Edit</a>
                                        <a href="blotter_group_record.php?delete=<?= $record['id'] ?>&page=<?= $page ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                                    </td>
                                    <td>
                                        <a href="blotter_group_record.php?toggle_status=<?= $record['id'] ?>&page=<?= $page ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>" class="status-button <?= $record['is_closed'] == 1 ? 'closed' : 'open' ?>">
                                            <?= $record['is_closed'] == 1 ? 'Case Closed' : 'Case Open' ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                    <!-- Pagination -->
                    <div class="pagination">
                        <a href="?page=1&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>" class="<?= $page == 1 ? 'disabled' : '' ?>">First</a>
                        <a href="?page=<?= max($page - 1, 1) ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>" class="<?= $page == 1 ? 'disabled' : '' ?>">Prev</a>
                        <span>Page <?= $page ?> of <?= $totalPages ?></span>
                        <a href="?page=<?= min($page + 1, $totalPages) ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>" class="<?= $page == $totalPages ? 'disabled' : '' ?>">Next</a>
                        <a href="?page=<?= $totalPages ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>" class="<?= $page == $totalPages ? 'disabled' : '' ?>">Last</a>
                    </div>
                <?php else: ?>
                    <p>No group records found.</p>
                <?php endif; ?>
            </div>
        </div>
        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2025 Lawa Management System. All rights reserved.</p>
        </div>
    </div>
</body>
</html>