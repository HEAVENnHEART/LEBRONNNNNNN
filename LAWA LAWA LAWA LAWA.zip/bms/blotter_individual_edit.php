<?php
include 'db.php';
// Start the session and check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    // If no session, redirect to login page
    header("Location: index.php");
    exit(); // Stop further execution
}
// Fetch the user's information based on the user_id stored in the session
$user_id = $_SESSION['user_id']; // Get the user ID from the session
try {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC); // Get user info
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}
// Check if the record ID is provided in the URL for editing
if (isset($_GET['id'])) {
    $recordId = $_GET['id'];
    
    // Fetch the existing record data based on the provided record ID
    try {
        $stmt = $pdo->prepare("SELECT * FROM records WHERE id = :recordId");
        $stmt->bindParam(':recordId', $recordId, PDO::PARAM_INT);
        $stmt->execute();
        $record = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$record) {
            // If no record found, redirect to individual-record.php
            header("Location: blotter_individual_record.php");
            exit();
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        exit;
    }
} else {
    // If no record ID is provided, redirect to individual-record.php
    header("Location: blotter_individual_record.php");
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $age = $_POST['age']; 
    $gender = $_POST['gender']; 
    $relationship = $_POST['relationship']; 
    // Combine month, day, and year into a single date string
    $month = $_POST['month']; 
    $day = $_POST['day']; 
    $year = $_POST['year'];
    $date = "$year-$month-$day"; // Combine into YYYY-MM-DD format
    $time = $_POST['time'];
    $address = $_POST['address'];
    $case = $_POST['case'];
    $description = $_POST['description'];
    $position = $_POST['position'];
    // Update record in `records` table
    try {
        $stmt = $pdo->prepare("UPDATE records SET name = ?, age = ?, gender = ?, relationship = ?, contact = ?, month = ?, day = ?, year = ?, time = ?, address = ?, case_type = ?, description = ?, position = ? WHERE id = ?");
        $stmt->execute([$name, $age, $gender, $relationship, $contact, $month, $day, $year, $time, $address, $case, $description, $position, $recordId]);

        // Update involved parties
        if (!empty($_POST['party_name'])) {
            // Remove existing involved parties first
            $stmt = $pdo->prepare("DELETE FROM involved_parties WHERE record_id = :record_id");
            $stmt->bindParam(':record_id', $recordId, PDO::PARAM_INT);
            $stmt->execute();

            // Insert new involved parties
            foreach ($_POST['party_name'] as $index => $partyName) {
                if (!empty($partyName)) {
                    $partyAge = $_POST['party_age'][$index];
                    $partyGender = $_POST['party_gender'][$index];
                    $partyAddress = $_POST['party_address'][$index];
                    
                    $stmt = $pdo->prepare("INSERT INTO involved_parties (record_id, name, age, gender, address) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$recordId, $partyName, $partyAge, $partyGender, $partyAddress]);
                }
            }
        }
        // Redirect to individual-record.php with success message
        header("Location: blotter_individual_record.php?success=Record updated successfully!");
        exit();
        
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blotter</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/blotter_individual_edit.css">
    
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-section">
                <a href="dashboard.php">
                    <img src="IMG/lawa-logo.jpg" alt="Logo" class="logo-image">
                </a>
            </div>
            <!-- Display the logged-in user's name in the sidebar -->
            <hr><br>
            <ul>
                <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
            </ul><br><hr><br>
            <ul>
                <li><a href="blotter_individual_record.php">Back</a></li>
            </ul>
        </div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Edit Blotter Form</h1>
            </div>
            <div class="container">
                <form id="recordForm" method="POST" action="blotter_individual_edit.php?id=<?= $recordId ?>">
                    <h3>Complainant</h3>

                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($record['name']) ?>" required>

                    <label for="age">Age:</label>
                    <input type="text" id="age" name="age" value="<?= htmlspecialchars($record['age']) ?>" required>

                    <label for="gender">Gender:</label>
                    <input type="text" id="gender" name="gender" value="<?= htmlspecialchars($record['gender']) ?>" required>

                    <label for="relationship">Relationship:</label>
                    <input type="text" id="relationship" name="relationship" value="<?= htmlspecialchars($record['relationship']) ?>" required>

                    <label for="contact">Contact Number:</label>
                    <input type="text" id="contact" name="contact" value="<?= htmlspecialchars($record['contact']) ?>" required>

                    <label for="address">Address:</label>
                    <input type="text" id="address" name="address" value="<?= htmlspecialchars($record['address']) ?>" required>

                    <label for="month">Month:</label>
                    <input type="text" id="month" name="month" value="<?= htmlspecialchars($record['month']) ?>" required>

                    <label for="day">Day:</label>
                    <input type="text" id="day" name="day" value="<?= htmlspecialchars($record['day']) ?>" required>

                    <label for="year">Year:</label>
                    <input type="text" id="year" name="year" value="<?= htmlspecialchars($record['year']) ?>" required>
                    
                    <label for="time">Time:</label>
                    <input type="time" id="time" name="time" value="<?= htmlspecialchars($record['time']) ?>" required>

                    <label for="case">Case:</label>
                    <input type="text" id="case" name="case" value="<?= htmlspecialchars($record['case_type']) ?>" required>
                    
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" required><?= htmlspecialchars($record['description']) ?></textarea>

                    <h3>Respondent</h3>
                    <div id="involvedParties">
                        <?php
                        // Fetch involved parties
                        $stmt = $pdo->prepare("SELECT * FROM involved_parties WHERE record_id = :record_id");
                        $stmt->bindParam(':record_id', $recordId, PDO::PARAM_INT);
                        $stmt->execute();
                        $parties = $stmt->fetchAll(PDO::FETCH_ASSOC);

                        foreach ($parties as $party) {
                            ?>
                            <div class="party">
                                <input type="text" name="party_name[]" value="<?= htmlspecialchars($party['name']) ?>" required>
                                <input type="text" name="party_age[]" value="<?= htmlspecialchars($party['age']) ?>" required>
                                <input type="text" name="party_gender[]" value="<?= htmlspecialchars($party['gender']) ?>" required>
                                <input type="text" name="party_address[]" value="<?= htmlspecialchars($party['address']) ?>" required>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <button type="button" id="addParty">Add Party</button>
                    <br>

                    <label for="position">Official:</label>
                    <input type="text" id="position" name="position" value="<?= htmlspecialchars($record['position']) ?>" required>

                    <div class="button-container">
                        <button type="submit">Update Record</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2025 Lawa Management System. All rights reserved.</p>
        </div>
    </div>
    <script src="JS/blotter_individual_edit.js"></script>
</body>
</html>
